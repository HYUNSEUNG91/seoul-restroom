import requests
from pymongo import MongoClient

# import urllib.parse

client = MongoClient("mongodb+srv://test:sparta@cluster0.6cz6m.mongodb.net/cluster0?retryWrites=true&w=majority")
db = client.seoul_restroom

headers = {'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36'}
a = requests.get('http://openapi.seoul.go.kr:8088/6e62516751786b7335386c4f67454f/json/SearchPublicToiletPOIService/1/1000/')

ajson = a.json()

rows = ajson['SearchPublicToiletPOIService']['row']

for row in rows:
    name = row['FNAME']
    X_WGS84 = row['X_WGS84']
    Y_WGS84 = row['Y_WGS84']

    doc = {
        'name': name,
        'X_WGS84':X_WGS84,
        'Y_WGS84': Y_WGS84
    }
    db.district.insert_one(doc)










